// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("concepts check"); }
int main(){
  announce();
  return lionss_run_workload("concepts-check");
}
