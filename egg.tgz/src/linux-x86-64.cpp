// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "linux x86 64");
  std::fflush(stdout);
  return lionss_run_workload("linux-x86-64");
}
